
# -*- coding: utf-8 -*- 

import os
import sys
import subprocess
import shutil

# ---------

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

# html/assets/config/config.json 파일 overwrite
config = '''
{
  "gateway": {
    "ip": "${addr}",
    "port": "18020"
  },
  "socket": {
    "ip": "${addr}",
    "port": "18060"
  }
}
'''


if len(sys.argv) == 3:
	if sys.argv[1] == 'start':
		addr = sys.argv[2]
		new_config = config.replace('${addr}', addr)
		print(new_config)
		
		with open(os.path.join(CURRENT_DIR, 'html/assets/config/config.json'), 'w') as configfile:
			configfile.write(new_config)
			
		# Run
		# Force Stop
		subprocess.call(['nginx', '-s', 'stop'])
		subprocess.call(['nginx'])
	else:
		print('static [start] [address-binding] | [stop]')
	
	
elif len(sys.argv) == 2 and sys.argv[1] == 'stop':
	subprocess.call(['nginx', '-s', 'stop'])
	print("Stopped")
	
else:
	print('static [start/stop] [address-binding]')